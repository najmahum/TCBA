import argparse
import os
from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential
from azure.ai.ml.entities import Model
from azure.ai.ml.constants import AssetTypes


def main():
    # 1. Setup Argument
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_input", type=str, help="Path folder hasil training")
    parser.add_argument("--model_name", type=str, help="Nama model untuk diregister")
    args = parser.parse_args()

    print(f"[REGISTER] Mulai mendaftarkan model: {args.model_name}")
    print(f"[REGISTER] Mengambil file dari path: {args.model_input}")

    # Cek isi folder
    print(f"[REGISTER] Isi folder model: {os.listdir(args.model_input)}")

    # 2. Setup Koneksi ke Azure
    credential = DefaultAzureCredential()
    ml_client = MLClient.from_config(credential=credential)

    # 3. Definisikan Model Object
    model = Model(
        path=args.model_input,
        name=args.model_name,
        description="Model GRU Prediksi Gempa + Scaler (Auto-Registered via Pipeline)",
        type=AssetTypes.CUSTOM_MODEL
    )

    # 4. Push ke Azure Registry
    registered_model = ml_client.models.create_or_update(model)

    print(f"Model terdaftar.")
    print(f"Nama: {registered_model.name}")
    print(f"Versi: {registered_model.version}")
    print(f"Path di Cloud: {registered_model.path}")


if __name__ == "__main__":
    main()