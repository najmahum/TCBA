import argparse
import pandas as pd
import numpy as np
import pyodbc
from pathlib import Path
import os
import sys


# ==========================================
# 1. FUNGSI ZALIAPIN (Sesuai kodemu)
# ==========================================
def calculate_zaliapin_logic(df):
    print("[ZALIAPIN] Memulai perhitungan nearest neighbor...")

    # Pastikan urut waktu
    df['time'] = pd.to_datetime(df['time'])
    df = df.sort_values('time').reset_index(drop=True)

    n = len(df)

    # Parameter Zaliapin
    b_value = 1.0
    d_fractal = 1.6

    # Siapkan array hasil
    nearest_dist = np.full(n, np.inf)
    parent_ids = [None] * n

    # Convert ke numpy array untuk kecepatan
    times = df['time'].values
    lats = df['latitude'].values
    lons = df['longitude'].values
    mags = df['mag'].values
    ids = df['id'].values

    # --- LOOPING ZALIAPIN ---
    # Note: Untuk data >10.000, ini mungkin butuh waktu beberapa menit
    for j in range(1, n):
        # Optimasi: Cek 2000 event terakhir saja biar gak O(N^2) full kalau datanya besar sekali
        # Kalau mau akurat 100%, hapus start_idx ini dan pakai :j
        lookback = 2000
        start_idx = max(0, j - lookback)

        # Slicing window
        t_past = times[start_idx:j]
        lat_past = lats[start_idx:j]
        lon_past = lons[start_idx:j]
        mag_past = mags[start_idx:j]

        # 1. Beda Waktu (Tahun)
        time_diffs = (times[j] - t_past).astype('timedelta64[ms]').astype(float) / (1000 * 3600 * 24 * 365.25)

        # 2. Jarak Spasial (Haversine) - KM
        dlat = np.radians(lats[j] - lat_past)
        dlon = np.radians(lons[j] - lon_past)
        a = np.sin(dlat / 2) ** 2 + np.cos(np.radians(lat_past)) * np.cos(np.radians(lats[j])) * np.sin(dlon / 2) ** 2
        r_ij = 2 * 6371 * np.arcsin(np.sqrt(a))
        r_ij = np.maximum(r_ij, 0.001)  # Hindari log(0)

        # 3. Zaliapin Distance (Eta)
        log_t = np.log10(time_diffs)
        log_r = np.log10(r_ij)
        log_eta = log_t + (d_fractal * log_r) + (b_value * (-mag_past))

        # 4. Cari Parent Terdekat
        min_idx_local = np.argmin(log_eta)

        nearest_dist[j] = log_eta[min_idx_local]
        # Map balik index local ke index global/ID sebenarnya
        parent_ids[j] = ids[start_idx + min_idx_local]

        if j % 500 == 0:
            print(f"Processing... {j}/{n}", end='\r')

    print(f"\n[ZALIAPIN] Selesai processing {n} data.")

    df['log_eta'] = nearest_dist
    df['parent_id'] = parent_ids
    return df


# ==========================================
# 2. FUNGSI LABELING (Mainshock/Aftershock)
# ==========================================
def apply_labels_and_features(df_zaliapin):
    print("[LABELING] Menentukan status gempa (Main/Fore/After)...")

    threshold_eta = -6.5

    # Helper Dictionary untuk lookup waktu parent dengan cepat
    time_dict = df_zaliapin.set_index('id')['time'].to_dict()

    def get_status(row):
        # 1. Cek Threshold Visual
        if row['log_eta'] >= threshold_eta:
            return 'Mainshock'  # Background

        # 2. Kalau Clustered, cek waktu vs Parent
        parent_time = time_dict.get(row['parent_id'])
        if parent_time is None:
            return 'Mainshock'  # Yatim piatu dianggap mainshock

        if row['time'] > parent_time:
            return 'Aftershock'
        else:
            return 'Foreshock'

    df_zaliapin['final_status'] = df_zaliapin.apply(get_status, axis=1)
    return df_zaliapin


# ==========================================
# 3. PREPARE TRAINING DATA (Target 24H)
# ==========================================
def create_training_dataset(df_full):
    print("[PREPARE] Menyusun dataset final untuk training...")

    # Filter kandidat: Hanya MAINSHOCK yang akan kita prediksi
    df_model = df_full[df_full['final_status'] == 'Mainshock'].copy()

    # Dataset anak-anak (Fore/After) untuk dicek
    df_children = df_full[df_full['final_status'].isin(['Aftershock', 'Foreshock'])].copy()

    # Lookup dictionaries biar cepat
    mainshock_times = df_model.set_index('id')['time'].to_dict()

    # Grouping anak-anak berdasarkan parent-nya
    # Ini jauh lebih cepat daripada apply row-by-row
    grouped_children = df_children.groupby('parent_id')

    # List penampung hasil
    targets = []
    num_foreshocks_list = []

    print(f"[PREPARE] Memproses {len(df_model)} mainshocks...")

    for mid in df_model['id']:
        if mid not in grouped_children.groups:
            # Gak punya anak sama sekali
            targets.append(0)
            num_foreshocks_list.append(0)
            continue

        my_children = grouped_children.get_group(mid)
        main_time = mainshock_times[mid]

        # Hitung Foreshock
        n_fore = len(my_children[my_children['final_status'] == 'Foreshock'])
        num_foreshocks_list.append(n_fore)

        # Cek Target Aftershock 24 Jam
        my_aftershocks = my_children[my_children['final_status'] == 'Aftershock']
        if len(my_aftershocks) > 0:
            time_diffs = my_aftershocks['time'] - main_time
            # Cek apakah ada yg <= 24 jam
            has_danger = any(time_diffs <= pd.Timedelta(hours=24))
            targets.append(1 if has_danger else 0)
        else:
            targets.append(0)

    df_model['label'] = targets  # Kita namakan 'label' agar sesuai script train.py
    df_model['num_foreshocks'] = num_foreshocks_list

    # Pilih kolom final untuk Training
    # Perhatikan: time dibuang, kita pakai num_foreshocks sebagai fitur sejarah
    cols_ready = ['latitude', 'longitude', 'depth', 'mag', 'num_foreshocks', 'label']

    print(f"[PREPARE] Dataset siap! Distribusi Label:\n{df_model['label'].value_counts()}")

    return df_model[cols_ready]


# ==========================================
# MAIN EXECUTION
# ==========================================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output_csv", required=True)
    parser.add_argument("--sql_server", required=True)
    parser.add_argument("--sql_db", required=True)
    parser.add_argument("--sql_user", required=True)
    parser.add_argument("--sql_password", required=True)
    args = parser.parse_args()

    # Handling Output Path
    out_path = Path(args.output_csv)
    if out_path.suffix == "":
        out_path.mkdir(parents=True, exist_ok=True)
        out_path = out_path / "data_gempa_ready.csv"
    else:
        out_path.parent.mkdir(parents=True, exist_ok=True)

    # 1. KONEKSI SQL & QUERY DATA MENTAH
    print("[SQL] Menghubungkan ke database...")
    conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={args.sql_server};DATABASE={args.sql_db};UID={args.sql_user};PWD={args.sql_password}"

    try:
        conn = pyodbc.connect(conn_str)
        query = "SELECT id, time, latitude, longitude, depth, mag FROM dbo.gempa"
        df_raw = pd.read_sql(query, conn)
        conn.close()
        print(f"[SQL] Berhasil menarik {len(df_raw)} data mentah.")
    except Exception as e:
        print(f"[ERROR] {e}")
        sys.exit(1)

    # Preprocessing Awal
    numeric_cols = ["latitude", "longitude", "depth", "mag"]
    for c in numeric_cols:
        df_raw[c] = pd.to_numeric(df_raw[c], errors="coerce")
    df_raw = df_raw.dropna()

    # 2. JALANKAN PROSES ZALIAPIN
    df_zaliapin = calculate_zaliapin_logic(df_raw)

    # 3. LABELING STATUS
    df_labeled = apply_labels_and_features(df_zaliapin)

    # 4. BUAT DATA TRAINING
    df_final = create_training_dataset(df_labeled)

    # 5. SAVE
    df_final.to_csv(out_path, index=False)
    print(f"[DONE] File tersimpan di: {out_path}")


if __name__ == "__main__":
    main()