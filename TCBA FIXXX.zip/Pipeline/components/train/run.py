import argparse
import os
import glob
import pandas as pd
import numpy as np
import joblib
import json
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, f1_score, accuracy_score
from imblearn.over_sampling import SMOTE
from model_GRU import build_gru_model, train_model

def main():
    # 1. Setup Arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_path", type=str, help="Folder input berisi CSV")
    parser.add_argument("--model_output", type=str, help="Folder output simpan model")
    args = parser.parse_args()

    print("=== Mulai Pipeline Training ===")

    # 2. Load Data
    csv_files = glob.glob(os.path.join(args.data_path, "*.csv"))
    if not csv_files: raise FileNotFoundError("CSV tidak ditemukan di folder input!")

    df = pd.read_csv(csv_files[0])
    print(f"[DATA] Loaded: {csv_files[0]} ({len(df)} baris)")

    feature_cols = ['latitude', 'longitude', 'depth', 'mag', 'num_foreshocks']
    target_col = 'label'

    X = df[feature_cols].values
    y = df[target_col].values

    # 3. Time Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

    # 4. Scaling
    print("[PREP] Scaling Data...")
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # 5. SMOTE (Hanya di Training Data)
    print(f"[PREP] SMOTE... (Sebelum: {np.bincount(y_train)})")
    smote = SMOTE(random_state=42)
    X_train_bal, y_train_bal = smote.fit_resample(X_train_scaled, y_train)
    print(f"[PREP] Selesai... (Sesudah: {np.bincount(y_train_bal)})")

    # 6. Reshape ke 3D (Samples, 1, Features)
    X_train_3d = X_train_bal.reshape((X_train_bal.shape[0], 1, len(feature_cols)))
    X_test_3d = X_test_scaled.reshape((X_test_scaled.shape[0], 1, len(feature_cols)))

    # ============================================
    # 7. TRAINING MODEL
    # ============================================
    print("[MODEL] Membangun Arsitektur...")
    model = build_gru_model(input_shape=(1, len(feature_cols)))

    print("[MODEL] Mulai Training...")
    train_model(model, X_train_3d, y_train_bal, X_test_3d, y_test, epochs=100)

    # ============================================
    # 8. EVALUASI DENGAN THRESHOLD
    # ============================================
    print("[EVAL] Evaluasi Model...")

    FIXED_THRESHOLD = 0.51

    # Prediksi Probabilitas
    y_pred_proba = model.predict(X_test_3d).flatten()
    y_pred_final = (y_pred_proba >= FIXED_THRESHOLD).astype(int)

    # Cetak Report
    print(f"AUC Score : {roc_auc_score(y_test, y_pred_proba):.4f}")
    print(f"Accuracy  : {accuracy_score(y_test, y_pred_final):.4f}")
    print(f"F1 Score  : {f1_score(y_test, y_pred_final, average='macro'):.4f}")
    print("\nConfusion Matrix:")
    print(confusion_matrix(y_test, y_pred_final))
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred_final))

    # 9. Simpan Hasil ke Output Folder
    os.makedirs(args.model_output, exist_ok=True)

    # Simpan Model (.h5)
    model.save(os.path.join(args.model_output, "model_gempa.h5"))

    # Simpan Scaler (.pkl)
    joblib.dump(scaler, os.path.join(args.model_output, "scaler.pkl"))

    # Simpan Threshold (.json)
    meta_path = os.path.join(args.model_output, "model_meta.json")
    with open(meta_path, "w") as f:
        json.dump({"best_threshold": FIXED_THRESHOLD}, f)

    print(f"[DONE] Model, Scaler, dan Meta (Threshold={FIXED_THRESHOLD}) tersimpan.")


if __name__ == "__main__":
    main()