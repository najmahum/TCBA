1. Jalanin untuk bikin pipeline awal
   az ml job create -f azure-ml/env/pipeline.yaml

2. deploy ke endpoint
   az ml online-endpoint create -f agile-ml/endpoint/endpoint.yaml

3. Online deployment agar bisa pake REST
   az ml online-deployment create -f azure-ml/endpoint/deployment.yaml

4. Kalo ada script berubah
   az ml online-deployment update -f azure-ml/endpoint/deployment.yaml

5. Scheduling retrain
   az ml schedule create -f azure-ml/env/pipeline_schedule.yaml

6. Cekking status
   az ml schedule show --name gold_weekly_retrain

7. Versi model terbaru
   az ml model list --name gold-lstm-final -o table

============================================================================================================

                              THE ARCHITECTURES
                        ┌────────────────────────────┐
                        │     Daily Scraper API      │
                        │  (Azure Function - Gold)   │
                        └──────────────┬─────────────┘
                                       │ JSON
                                       ▼
                          ┌────────────────────────┐
                          │     Pipeline Step:     │
                          │        SCRAPE          │
                          └────────────┬───────────┘
                                       │ CSV (prices)
                                       ▼
                          ┌────────────────────────┐
                          │     Pipeline Step:     │
                          │         TRAIN          │
                          │   LSTM Walk-Forward    │
                          └────────────┬───────────┘
                                       │ model + scalers
                                       ▼
                          ┌────────────────────────┐
                          │     Pipeline Step:     │
                          │       REGISTER         │
                          │  Register Model vN     │
                          └────────────┬───────────┘
                                       │ new model version
                                       ▼
                         ┌─────────────────────────────┐
                         │  Azure ML Online Endpoint   │
                         │    gold-lstm-endpoint       │
                         ├─────────────────────────────┤
                         │ Deployment: golddeploy      │
                         │ Scoring Script: azurescore.py│
                         └─────────────────────────────┘
                                       ▲
                                       │
                         ┌─────────────────────────────┐
                         │ Weekly Retrain Schedule     │
                         │ Every Sunday, 17:00         │
                         └─────────────────────────────┘

============================================================================================================
📌 2. Pipeline Components Explanation
🔹 1. Scrape Component (components/scrape)

Mengambil harga emas real-time dari API.

Output: output_csv (historical price data) dalam bentuk CSV.

🔹 2. Train Component (components/train)

Mengambil CSV hasil scrape.

Melakukan preprocessing, scaling, dan training LSTM Walk-Forward.

Menyimpan:

lstm_model.keras

scaler_X.joblib

scaler_y.joblib

Output: folder model untuk pipeline berikutnya.

🔹 3. Register Component (components/register)

Mengambil model dari step training.

Register ke Model Registry sebagai gold-lstm-final:version.

Tidak overwrite, tetapi membuat versi baru otomatis.

============================================================================================================
CONTOH REQUEST JSONNYA (PASTIIN TANGGAL LEBIH DARI DATA TERAKHIR DALAM HISTORICAL DATA)
{
"target_date": "2025-12-10"
}

============================================================================================================

- Gimana sih sistemnya??

Sistem ini bekerja dengan mengambil data harga emas harian dari yfinance yang sudah di scrape datanya dengan function yang sudah disiapkan, menjalankannya melalui pipeline Azure ML yang terdiri dari scraping, training LSTM walk-forward, dan model registration; pipeline ini dijadwalkan untuk berjalan otomatis tiap minggu pada jam 17:00 untuk melakukan retraining berdasarkan data terbaru, menghasilkan model versi baru, dan siap untuk di-deploy; endpoint real-time (gold-lstm-endpoint) menggunakan model terbaru untuk melakukan forecasting harga emas di tanggal yang ditentukan oleh pengguna menggunakan LSTM dan scaler yang dipelajari dari data historis.

============================================================================================================
Troubelshooting Guide:
502 — Liveness Probe Failed

Penyebab:

init() error

model tidak ditemukan

environment tidak sesuai

dependency kurang (TensorFlow / joblib / requests)

Solusi:

Cek model dir di container:

print("MODEL_DIR:", os.listdir(MODEL_DIR))

Pastikan file:

lstm_model.keras

scaler_X.joblib

scaler_y.joblib

Pastikan environment:

- tensorflow==2.12.0
- azureml-inference-server-http

❗ 408 Upstream Timeout (Endpoint Test Timeout)

Penyebab:

Model terlalu berat untuk DS2_v2

Prediksi memakan waktu terlalu lama

API scrape lambat

Solusi:

Gunakan instance lebih kencang minimal Standard_DS3_v2

Perpendek inference: kurangi langkah forecast

Pastikan API scrape mengembalikan data cepat

❗ Model Path Not Found (FileNotFoundError)

Penyebab:

Kamu menaruh model di subfolder (dulu LSTM_WALKFORWARD/)

Deployment dir menggunakan root model

Solusi:

Gunakan:
MODEL_DIR = Path(os.getenv("AZUREML_MODEL_DIR", ""))

Bukan:
/AZUREML_MODEL_DIR/LSTM_WALKFORWARD

❗ Schedule Tidak Jalan
Solusi cek:

az ml schedule show --name gold_weekly_retrain

Pastikan:

is_enabled: true
provisioning_state: Succeeded

❗ Register Tidak Update

Cek versi model:

az ml model list --name gold-lstm-final -o table

Jika versi tetap → pipeline step register gagal atau tidak jalan.
