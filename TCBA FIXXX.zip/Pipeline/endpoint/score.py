import json
import os
import joblib
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import load_model
from pathlib import Path

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"


def init():
    global model, scaler, threshold
    model_dir = os.getenv("AZUREML_MODEL_DIR", ".")
    model_dir = Path(model_dir)

    print(f"[INIT] Mencari file di: {model_dir}")

    # 1. Cari File Model
    model_path_list = list(model_dir.rglob("model_gempa.h5"))
    if not model_path_list:
        raise FileNotFoundError("Error: model_gempa.h5 tidak ditemukan!")
    model_path = model_path_list[0]

    # 2. Cari File Scaler (.pkl)
    scaler_path_list = list(model_dir.rglob("scaler.pkl"))
    if not scaler_path_list:
        raise FileNotFoundError("Error: scaler.pkl tidak ditemukan!")
    scaler_path = scaler_path_list[0]

    # 3. Cari Threshold (.json)
    meta_path_list = list(model_dir.rglob("model_meta.json"))

    # Load Semua
    print(f"[INIT] Loading Model: {model_path}")
    model = load_model(model_path)

    print(f"[INIT] Loading Scaler: {scaler_path}")
    scaler = joblib.load(scaler_path)

    # Load Threshold (atau default ke 0.51 kalau file json hilang)
    if meta_path_list:
        print(f"[INIT] Loading Metadata: {meta_path_list[0]}")
        with open(meta_path_list[0], 'r') as f:
            meta = json.load(f)
            threshold = meta.get("best_threshold", 0.51)
    else:
        print("[INIT] Metadata tidak ketemu, pakai default 0.51")
        threshold = 0.51

    print(f"[INIT] SIAP! Threshold aktif: {threshold}")


def run(raw_data):
    try:
        # 1. Parse Input JSON
        data = json.loads(raw_data)

        # Validasi Input
        required_keys = ['latitude', 'longitude', 'depth', 'mag', 'num_foreshocks']
        if not all(key in data for key in required_keys):
            return {"error": f"Input harus mengandung: {required_keys}"}

        # 2. Preprocessing
        input_df = pd.DataFrame([data])

        # Scaling
        input_scaled = scaler.transform(input_df)

        # Reshape ke 3D untuk GRU (1 Sample, 1 Timestep, 5 Features)
        input_reshaped = input_scaled.reshape(1, 1, 5)

        # 3. Prediksi
        probabilitas = model.predict(input_reshaped, verbose=0)[0][0]

        # 4. Keputusan (Pakai Threshold)
        prediksi_kelas = 1 if probabilitas >= threshold else 0
        label_str = "BAHAYA (Potensi Aftershock)" if prediksi_kelas == 1 else "AMAN (Mainshock Tunggal)"

        # 5. Return JSON Result
        result = {
            "prediction": label_str,
            "status": int(prediksi_kelas),
            "probability": float(probabilitas),
            "threshold_used": float(threshold),
            "input_received": data
        }

        print(f"[RUN] Request processed. Result: {label_str} ({probabilitas:.4f})")
        return result

    except Exception as e:
        print(f"[ERROR] {str(e)}")
        return {"error": str(e)}