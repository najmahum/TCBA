from azure.ai.ml import MLClient, load_job
from azure.identity import DefaultAzureCredential
from azure.ai.ml.entities import AmlCompute, Environment
from azure.core.exceptions import ResourceNotFoundError

# ==============================================================
# KONFIGURASI
# ==============================================================
SUBSCRIPTION_ID = "c6adba65-fe84-4684-808b-cde6efd99e56"
RESOURCE_GROUP = "PROJECT_TCBA"
WORKSPACE_NAME = "tcba-kelompok-1"

COMPUTE_NAME = "cpu-cluster"
ENV_NAME = "project_gempa_env"
CONDA_PATH = "./env/deployment_conda.yaml"
PIPELINE_FILE = "./pipeline.yaml"

def main():
    # 1. KONEKSI KE AZURE
    print(f"🔌 Menghubungkan ke Workspace: {WORKSPACE_NAME}...")
    credential = DefaultAzureCredential()
    ml_client = MLClient(
        credential=credential,
        subscription_id=SUBSCRIPTION_ID,
        resource_group_name=RESOURCE_GROUP,
        workspace_name=WORKSPACE_NAME
    )
    print("Terhubung!")

    # 2. SETUP COMPUTE CLUSTER (OTOMATIS)
    print(f"\n⚙Cek Compute Cluster: {COMPUTE_NAME}...")
    try:
        cluster = ml_client.compute.get(COMPUTE_NAME)
        print(f"Cluster '{COMPUTE_NAME}' sudah ada. Skip pembuatan.")
    except ResourceNotFoundError:
        print(f"Cluster tidak ditemukan. Membuat '{COMPUTE_NAME}' baru...")
        cluster = AmlCompute(
            name=COMPUTE_NAME,
            type="amlcompute",
            size="STANDARD_DS11_V2",  # Size standar, bisa diganti
            min_instances=0,
            max_instances=2,
            idle_time_before_scale_down=120,
        )
        ml_client.compute.begin_create_or_update(cluster).result()
        print(f"Cluster '{COMPUTE_NAME}' berhasil dibuat!")

    # 3. SETUP ENVIRONMENT
    print(f"\nCek Environment: {ENV_NAME}...")
    try:
        pipeline_job_env = Environment(
            name=ENV_NAME,
            description="Environment Otomatis Project Gempa",
            conda_file=CONDA_PATH,
            image="mcr.microsoft.com/azureml/openmpi4.1.0-ubuntu20.04:latest",
            version="1"
        )
        ml_client.environments.create_or_update(pipeline_job_env)
        print(f"Environment '{ENV_NAME}' berhasil didaftarkan/diupdate!")
    except Exception as e:
        print(f"Gagal register environment: {e}")
        return

    # 4. SUBMIT PIPELINE
    print(f"\nMengirim Pipeline Job dari file: {PIPELINE_FILE}...")
    try:
        # Load pipeline dari YAML
        pipeline_job = load_job(source=PIPELINE_FILE)

        # Submit job
        returned_job = ml_client.jobs.create_or_update(pipeline_job)

        print(f"Job Terkirim! Status: {returned_job.status}")
        print(f"Link Job: {returned_job.studio_url}")

    except Exception as e:
        print(f"Gagal submit pipeline: {e}")


if __name__ == "__main__":
    main()