import argparse, os, pandas as pd, numpy as np, joblib
from tensorflow.keras.models import load_model

OPTIMAL_THRESHOLD = 0.7455

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_csv", required=True)
    parser.add_argument("--output_csv", required=True)
    parser.add_argument("--model_dir", required=True)
    args = parser.parse_args()

    df = pd.read_csv(args.input_csv)

    model = load_model(os.path.join(args.model_dir, "outputs", "model_gru_gempa.keras"))
    scaler = joblib.load(os.path.join(args.model_dir, "outputs", "scaler_X.pkl"))

    feature_cols = ["latitude","longitude","depth","mag","num_foreshocks","energy_log"]
    X = df[feature_cols].values
    Xs = scaler.transform(X)
    X3d = Xs.reshape((Xs.shape[0], 1, Xs.shape[1]))

    prob = model.predict(X3d, verbose=0).reshape(-1)
    label = (prob >= OPTIMAL_THRESHOLD).astype(int)

    out = pd.DataFrame({"probability": prob, "label": label})
    out.to_csv(args.output_csv, index=False)

if __name__ == "__main__":
    main()
