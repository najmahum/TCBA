import argparse, pyodbc, pandas as pd, os

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output_csv", required=True)
    args = parser.parse_args()

    server = os.environ.get('SQL_SERVER')
    database = os.environ.get('SQL_DATABASE')
    username = os.environ.get('SQL_USERNAME')
    password = os.environ.get('SQL_PASSWORD')
    conn_str = (
        f"Driver={{ODBC Driver 17 for SQL Server}};"
        f"Server=tcp:{server},1433;"
        f"Database={database};"
        f"Uid={username};"
        f"Pwd={password};"
        "Encrypt=yes;"
        "TrustServerCertificate=no;"
        "Connection Timeout=30;"
    )

    query = "SELECT latitude, longitude, depth, mag, time FROM GEMPA ORDER BY time ASC"
    with pyodbc.connect(conn_str) as conn:
        df = pd.read_sql(query, conn)

    # Feature engineering
    df["energy_log"] = 4.8 + (1.5 * df["mag"])
    df["num_foreshocks"] = 0

    cols = ["latitude","longitude","depth","mag","num_foreshocks","energy_log"]
    df_out = df[cols].copy()
    df_out.to_csv(args.output_csv, index=False)

if __name__ == "__main__":
    main()
