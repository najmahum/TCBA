import json
import joblib
import numpy as np
import pandas as pd
import os
import pyodbc
import logging
from tensorflow.keras.models import load_model

# --- KONFIGURASI ---
OPTIMAL_THRESHOLD = 0.7455

def init():
    global model, scaler, db_connection_str
    
    model_dir = os.getenv("AZUREML_MODEL_DIR")
    logging.info(f"Loading resources from: {model_dir}")
    
    try:
        model = load_model(os.path.join(model_dir, "outputs", "model_gru_gempa.keras"))
        scaler = joblib.load(os.path.join(model_dir, "outputs", "scaler_X.pkl"))
    except Exception as e:
        logging.error(f"Gagal load model/scaler: {str(e)}")
        raise e
    
    # Pastikan variable ini sudah disetting di Environment Variables Azure Endpoint
    server = os.environ.get('SQL_SERVER')
    database = os.environ.get('SQL_DATABASE')
    username = os.environ.get('SQL_USERNAME')
    password = os.environ.get('SQL_PASSWORD')
    
    db_connection_str = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}'
    logging.info("Init selesai.")

def calculate_foreshocks_from_sql(lat, lon, mag, time_current):
    """
    Menghitung gempa kecil sebelum kejadian utama.
    Karena data training tidak punya statistik foreshock, kita pakai Rule of Thumb:
    - Waktu: 7 Hari ke belakang
    - Radius: ~50km (0.2 derajat kuadrat)
    - Mag: Lebih kecil dari gempa saat ini
    """

    radius_sq = 0.2 
    days_back = 7
    
    query = f"""
    SELECT COUNT(*) 
    FROM GEMPA 
    WHERE 
        time < '{time_current}' 
        AND time >= DATEADD(day, -{days_back}, '{time_current}')
        AND mag < {mag} 
        AND (SQUARE(latitude - {lat}) + SQUARE(longitude - {lon})) < {radius_sq}
    """
    try:
        with pyodbc.connect(db_connection_str) as conn:
            cursor = conn.cursor()
            cursor.execute(query)
            count = cursor.fetchone()[0]
            return count
    except Exception as e:
        logging.warning(f"SQL Error (Foreshock): {str(e)}. Default 0.")
        return 0

def run(raw_data):
    try:
        input_json = json.loads(raw_data)
        item = input_json['data'][0]
        
        mag = float(item['mag'])
        lat = float(item['latitude'])
        lon = float(item['longitude'])
        depth = float(item['depth'])
        time_evt = item['time']

        # --- FEATURE ENGINEERING ---
        energy_log = 4.8 + (1.5 * mag)
        num_foreshocks = calculate_foreshocks_from_sql(lat, lon, mag, time_evt)
        
        # --- PREDIKSI ---
        features = np.array([[lat, lon, depth, mag, num_foreshocks, energy_log]])
        
        features_scaled = scaler.transform(features)
        input_gru = features_scaled.reshape(1, 1, features_scaled.shape[1])
        
        probabilitas = model.predict(input_gru, verbose=0)[0][0]
        
        status = "BAHAYA (SIAGA 1)" if probabilitas >= OPTIMAL_THRESHOLD else "AMAN"
        
        return {
            "status_prediksi": status,
            "probabilitas_bahaya": float(probabilitas),
            "threshold_acuan": OPTIMAL_THRESHOLD,
            "info_tambahan": {
                "foreshock_terdeteksi": num_foreshocks,
                "energy_log": round(energy_log, 2)
            }
        }

    except Exception as e:
        logging.error(f"Runtime Error: {str(e)}")
        return {"error": f"Gagal memprediksi: {str(e)}"}