import os
import logging
import pyodbc
import pandas as pd
import numpy as np
import joblib
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, GRU, Dropout
from tensorflow.keras.regularizers import l2
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from imblearn.over_sampling import SMOTE

# --- Ambil kredensial dari Env Var ---
server = os.environ.get('SQL_SERVER')
database = os.environ.get('SQL_DATABASE')
username = os.environ.get('SQL_USERNAME')
password = os.environ.get('SQL_PASSWORD')
conn_str = (
    f"Driver={{ODBC Driver 17 for SQL Server}};"
    f"Server=tcp:{server},1433;"
    f"Database={database};"
    f"Uid={username};"
    f"Pwd={password};"
    "Encrypt=yes;"
    "TrustServerCertificate=no;"
    "Connection Timeout=30;"
)

# --- Fungsi Zaliapin ---
def calculate_nearest_neighbor(df, b_value=1.0, d_fractal=1.6):
    # Pastikan time bertipe datetime
    if not np.issubdtype(df['time'].dtype, np.datetime64):
        df['time'] = pd.to_datetime(df['time'], errors='coerce')

    df = df.sort_values('time').reset_index(drop=True)
    n = len(df)
    nearest_dist = np.full(n, np.inf)
    parent_ids = [None] * n

    times = df['time'].values
    lats = df['latitude'].values
    lons = df['longitude'].values
    mags = df['mag'].values
    ids = df['id'].values

    for j in range(1, n):
        # beda waktu dalam tahun (hindari nol/negatif)
        dt = (times[j] - times[:j]).astype('timedelta64[ms]').astype(float)
        # ganti nilai <= 0 jadi kecil positif agar log10 tidak -inf
        dt = np.where(dt <= 0, 1.0, dt)
        time_diffs_years = dt / (1000 * 3600 * 24 * 365.25)

        dlat = np.radians(lats[j] - lats[:j])
        dlon = np.radians(lons[j] - lons[:j])
        a = np.sin(dlat/2)**2 + np.cos(np.radians(lats[:j])) * np.cos(np.radians(lats[j])) * np.sin(dlon/2)**2
        r_ij = 2 * 6371 * np.arcsin(np.sqrt(a))
        r_ij = np.maximum(r_ij, 0.001)  # cegah nol

        m_i = mags[:j]

        log_t = np.log10(time_diffs_years)
        log_r = np.log10(r_ij)
        log_eta = log_t + (d_fractal * log_r) - (b_value * m_i)

        min_idx = np.argmin(log_eta)
        nearest_dist[j] = log_eta[min_idx]
        parent_ids[j] = ids[min_idx]

    df['log_eta'] = nearest_dist
    df['parent_id'] = parent_ids
    return df

def assign_zaliapin_label(row, threshold_eta=-6.5):
    return 'Clustered' if row['log_eta'] < threshold_eta else 'Background'

def final_labeling(df):
    time_dict = df.set_index('id')['time'].to_dict()
    def fast_label(row):
        if row['zaliapin_label'] == 'Background':
            return 'Mainshock'
        parent_time = time_dict.get(row['parent_id'])
        if parent_time is None:
            return 'Mainshock'
        return 'Aftershock' if row['time'] > parent_time else 'Foreshock'
    return df.apply(fast_label, axis=1)

def main():
    print("1. Menarik data dari SQL...")
    query = "SELECT * FROM GEMPA ORDER BY time ASC"
    with pyodbc.connect(conn_str) as conn:
        df = pd.read_sql(query, conn)

    print("SQL_SERVER:", server)
    print("SQL_DATABASE:", database)
    print("SQL_USERNAME:", username)
    print("SQL_PASSWORD:", "****" if password else None)
    print(f"Total Data (raw): {len(df)}")

    # --- 2. PREPROCESSING & ZALIAPIN ---
    # Bersihkan kolom inti dari NaN dulu (id, time, lat, lon, depth, mag)
    essential_cols = ['id', 'time', 'latitude', 'longitude', 'depth', 'mag']
    before_drop = df[essential_cols].isna().sum()
    print("NaN sebelum Zaliapin (kolom inti):")
    print(before_drop.to_dict())

    df = df.dropna(subset=essential_cols)
    print(f"Total Data setelah drop NaN inti: {len(df)}")

    df_zaliapin = calculate_nearest_neighbor(df)
    df_zaliapin['zaliapin_label'] = df_zaliapin.apply(assign_zaliapin_label, axis=1)
    df_zaliapin['final_status'] = final_labeling(df_zaliapin)

    # Feature tambahan
    # Pastikan mag valid sebelum hitung energy_log
    df_zaliapin['energy_log'] = 4.8 + (1.5 * df_zaliapin['mag'])

    # num_foreshocks: parent_id None bisa bikin NaN; isi dengan 0
    df_zaliapin['num_foreshocks'] = (
        df_zaliapin.groupby('parent_id')['final_status']
        .transform(lambda x: (x == 'Foreshock').sum())
    )
    df_zaliapin['num_foreshocks'] = df_zaliapin['num_foreshocks'].fillna(0)

    # Target
    df_zaliapin['has_aftershock_24h'] = df_zaliapin['final_status'].apply(lambda x: 1 if x == 'Aftershock' else 0)

    # Cek NaN pada fitur final
    feature_cols = ['latitude', 'longitude', 'depth', 'mag', 'num_foreshocks', 'energy_log']
    nan_counts = df_zaliapin[feature_cols].isna().sum()
    print("NaN pada fitur final (sebelum imputasi):")
    print(nan_counts.to_dict())

    # --- 3. SPLIT & SCALE (dengan imputasi median) ---
    X = df_zaliapin[feature_cols].values
    y = df_zaliapin['has_aftershock_24h'].values

    # Imputer untuk ganti NaN yang tersisa dengan median
    imputer = SimpleImputer(strategy="median")
    X = imputer.fit_transform(X)

    split = int(len(X) * 0.8)
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # --- 4. BALANCING ---
    smote = SMOTE(random_state=42)
    X_train_bal, y_train_bal = smote.fit_resample(X_train_scaled, y_train)

    # Reshape 3D untuk GRU
    X_train_3d = X_train_bal.reshape((X_train_bal.shape[0], 1, X_train_bal.shape[1]))
    X_test_3d = X_test_scaled.reshape((X_test_scaled.shape[0], 1, X_test_scaled.shape[1]))

    # --- 5. TRAINING MODEL ---
    print("Training Model GRU...")
    model = Sequential([
        GRU(32, kernel_regularizer=l2(1e-4), input_shape=(1, X_train_bal.shape[1]), return_sequences=False),
        Dropout(0.3),
        Dense(16, activation='relu'),
        Dense(1, activation='sigmoid')
    ])

    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    early_stop = EarlyStopping(monitor='val_loss', patience=8, restore_best_weights=True)

    model.fit(
        X_train_3d, y_train_bal,
        epochs=50,
        validation_data=(X_test_3d, y_test),
        callbacks=[early_stop],
        verbose=1
    )

    # --- 6. SAVE & REGISTER ---
    print("Menyimpan Model...")
    os.makedirs('outputs', exist_ok=True)
    model.save('outputs/model_gru_gempa.keras')
    joblib.dump(scaler, 'outputs/scaler_X.pkl')

    print("Retraining selesai. File siap di-upload ke Azure Model Registry.")

if __name__ == "__main__":
    main()
