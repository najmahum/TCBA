import azure.functions as func
import pyodbc
import json
import os
import requests
import struct
from azure.cosmos import CosmosClient
from azure.identity import DefaultAzureCredential

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

credential = DefaultAzureCredential()

#share data
@app.route(route="share_data")
def share_data(req: func.HttpRequest) -> func.HttpResponse:
    try:
        token_bytes = credential.get_token("https://database.windows.net/.default").token.encode("UTF-16-LE")
        token_struct = struct.pack(f'<I{len(token_bytes)}s', len(token_bytes), token_bytes)
        SQL_COPT_SS_ACCESS_TOKEN = 1256

        conn = pyodbc.connect(
            f"Driver={{ODBC Driver 18 for SQL Server}};"
            f"Server=tcp:{os.getenv('SQL_SERVER')},1433;"
            f"Database={os.getenv('SQL_DATABASE')};"
            "Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;",
            attrs_before={SQL_COPT_SS_ACCESS_TOKEN: token_struct}
        )

        cursor = conn.cursor()
        cursor.execute("SELECT * FROM datakel6") 
        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchall()

        data = [dict(zip(columns, row)) for row in rows]

        cursor.close()
        conn.close()

        return func.HttpResponse(
            json.dumps(data, default=str),
            mimetype="application/json",
            status_code=200
        )

    except Exception as e:
        return func.HttpResponse(
            f"Error saat ambil data SQL: {str(e)}",
            status_code=500
        )


#SCRAP
@app.route(route="scrap_data")
def scrap_data(req: func.HttpRequest) -> func.HttpResponse:
    try:
        target_url = "https://scrapmohammadadibalfiyan-gzbtathjd8ebbmh8.indonesiacentral-01.azurewebsites.net/api/share_data?code=RanwFcNkVCXBo0YfzQfqxD_fH-L9j0BROBs_Dokzx6D9AzFu-Ue8ag=="
        response = requests.get(target_url)
        if response.status_code != 200:
            return func.HttpResponse(
                f"Gagal ambil data dari {target_url}, status {response.status_code}",
                status_code=500
            )

        data = response.json()

        client = CosmosClient(os.getenv("COSMOS_ENDPOINT"), credential=credential)
        database = client.get_database_client(os.getenv("COSMOS_DB"))
        container = database.get_container_client(os.getenv("COSMOS_CONTAINER"))

        inserted = 0
        for item in data:
            item["id"] = str(item.get("id", hash(json.dumps(item))))
            container.upsert_item(item)
            inserted += 1

        return func.HttpResponse(
            f"{inserted} data berhasil di-scrap dari {target_url} dan disimpan ke Cosmos DB",
            status_code=200
        )

    except Exception as e:
        return func.HttpResponse(
            f"Error saat scrap atau insert ke Cosmos: {str(e)}",
            status_code=500
        )